server main class: com.obfuscation.server.Server

WINDOWS: java -cp server.jar;gson-2.8.5.jar com.obfuscation.server.Server
LINUX:   java -cp server.jar:gson-2.8.5.jar com.obfuscation.server.Server

client main class: com.obfuscation.ttr_phase1b.gameViews.GameActivity

Nexus 5X API 27
